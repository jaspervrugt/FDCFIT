%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%% FFFFFFFFFFF DDDDDDDDD  CCCCCCCCCC FFFFFFFFFFF IIIIIIIIIIII TTTTTTTTTT %%
%% FFFFFFFFFFF DDDDDDDDDD CCCCCCCCC  FFFFFFFFFFF  IIIIIIIIII  TTTTTTTTTT %%
%% FF          DD      DD CC         FF               II          TT     %%
%% FF          DD      DD CC         FF               II          TT     %%
%% FFFFFF      DD      DD CC         FFFFFF           II          TT     %%
%% FF          DD      DD CC         FF               II          TT     %%
%% FF          DDDDDDDDDD CCCCCCCCC  FF           IIIIIIIIII      TT     %%
%% FF          DDDDDDDDD  CCCCCCCCCC FF          IIIIIIIIIIII     TT     %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
% For more details regarding this work refer to the two following papers  %
%                                                                         %
% 1. Vrugt, J.A., and M. Sadegh (2013), Toward diagnostic model           %
%    calibration and evaluation: Approximate Bayesian computation, Water  %
%    Resources Research, 49, 4335�4345, doi:10.1002/wrcr.20354.           %
% 2. Sadegh, M., J.A. Vrugt, X. Cu, and H.V. Gupta, (2016), The soil      %
%    water characteristic as new class of parametric expressions of the   %
%    flow duration curve, Journal of Hydrology, 535, p. 438-456,          %
%    doi.org/10.1016/j.jhydrol.2016.01.027.                               %
% 3. Vrugt, J.A. (2017), FDCFIT: A MATLAB toolbox of parametric           %
%    expressions of the Flow duration curve, Manual, p. 1-37.             %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SYNOPSIS  [x,RMSE] = FDCFIT(FDCPar,E,Y);                                %
%           [x,RMSE] = FDCFIT(FDCPar,E,Y,optim);                          %
%           [x,RMSE] = FDCFIT(FDCPar,E,Y,optim,options);                  %
% INPUT     FDCPar     structure with settings for FDCFIT                 %
%           E          empirical exceedance probability                   %
%           Y          empirical ( = measured ) discharge                 %
%           optim      optional structure settings optimization method    %
%           options    optional structure for screen output               %
% OUTPUT    x          optimized values of coefficients of the FDC model  %
%           RMSE       root mean square error of fit to empirical FDC     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                     Written by Jasper A. Vrugt                          %
%                   University of California Irvine                       %
%                           December 2014                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
% Version 1: December, 2014                                               %
% Version 1.1: Feb, 2016                                                  %
% Version 1.2: May, 2017                                                  %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% The following models are part of the toolbox
% "model"   "name"      "acronym used in paper Sadegh, Vrugt (REF 2)"
% [ 1 ] 'lognormal-2'    LN-2
% [ 2 ] 'gumbel'         G
% [ 3 ] 'logistic'       LG
% [ 4 ] 'logarithmic'    LOG
% [ 5 ] 'power'          PW
% [ 6 ] 'quimpo'         Q
% [ 7 ] 'viola'          V
% [ 8 ] 'genuchten-2'    VG-2
% [ 9 ] 'kosugi-2'       K-2
% [ 10 ] 'lognormal-3'   LN-3
% [ 11 ] 'pareto'        GP
% [ 12 ] 'gev'           GEV
% [ 13 ] 'franchini'     F
% [ 14 ] 'genuchten-3'   VG-3
% [ 15 ] 'kosugi-3'      K-3

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% %                         SETUP OF PROBLEM                            % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

% Define model and formulation
% FDCPar.model = 15;          % Which model do you want to use? Input: [1...15]   ( See list above )
%
% FDCPar.formulation = 'Y';   % Fitting approach (fit to observed exceedance probability or streamflow)
%                             % Options: 'E'        Against exceedance probability
%                             %          'Y'        Against streamflow
% 
% FDCPar.method = 'LM';       % Optimization method used to derive the coefficients of the FDC model
%                             % Options: 'LM'    Levenberg Marquardt                                ( = local gradient-based method )
%                             %          'SP'    Nelder-Mead Simplex                                ( = local method )
%                             %          'CMA'   Covariance Matrix Adaptation Evolutionary Strategy ( = global method )
%                             %          'DE'    Differential Evolution                             ( = global method )
% 
% % Define fields of structure optim
% optim.N = 5;                % Number of trials with Levenberg Marquardt/Simplex method             ( default: 5)
% optim.P = 25;               % DE or CMA Population size                                            ( default: 25 )
% optim.CR = 0.8;             % DE Crossover value                                                   ( default: 0.8 )
% optim.TolX = 1e-2;          % Termination criteria on parameters                                   ( default: 0.01 )
% optim.TolFun = 1e-3;        % Termination criteria on objective function ( SSE )                   ( default: 0.001 )
% optim.MaxFunEvals = 2e4;    % Maximum number of function evaluations with each method (per trial)  ( default: 2e4 )
% 
% Define fields of structure options
% options.type = 'daily';     % Time scale of flow duration curve ( 'daily'/'weekly'/'monthly'/'annual' )
% options.print = 'yes';      % Output to screen ( 'yes' or 'no' )
% 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% %                CHECK EXAMPLE DIRECTORIES FOR CASE STUDIES             % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% 

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% %                          SETUP OF THE CODE                            % %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

% Add main AMALGAM directory and underlying postprocessing directory
addpath(pwd);
% Now go to example 1
cd example_1
% And you can now execute example_1 using (uncomment)
% example_1